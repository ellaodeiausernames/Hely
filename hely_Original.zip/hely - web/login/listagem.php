<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listagem</title>
    <link href="listagem.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>
<body>
    <section>
        
        <header>
        

            <a href="#"> <img src="img/logo.png" alt="" class="logo"> </a>
            <div class="bx bx-menu" id="menu-icon"></div>

            <ul class="navbar">

                <li class="dropdown" >
                <a href="javascript:void(0)" class="dropbtn" id="dropbtn">Menu</a>
                    <div class="dropdown-content" >
                        <a href="index.php" >Cadastre-se</a>
                        <a href="index.php">Entre</a>
                        <a href="listagem.php">Listagem</a>
                    </div></li>

                <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn" id="dropbtn">Todos</a>
                <div class="dropdown-content">
                    <a href="#familia">Familia</a>
                    <a href="#amigos">Amigos</a>
                    <a href="listagem.php">Listagem</a>
                </div></li>

                <li id="nav"><a href="#favoritos">Favoritos</a></li>

               <li id="nav" ><a href="#sobre">Sobre</a></li>
        </ul>
    
    
        </header>
        <div class="content" id="menu">
            <div class="textbox">
                <h2>Hely<br><span>Listagem</span></h2>
                <p>Listagem de todos os usuários com pesquisa<br>Entre ou cadastre-se!</p>
                <a href="login/index.php" class="btn">Participe!</a>
            </div>
            <form method="GET" action="listagem.php">
                <input type="text" name="pesquisa"  placeholder="Pesquisar usuário">
                
                <button type="submit">Pesquisar</button>
            </form>

            <?php
            // Configurações do banco de dados
            $host = 'localhost'; // Host do banco de dados
            $dbname = 'helybd'; // Nome do banco de dados
            $usuario = 'root'; // Nome de usuário do MySQL
            $senha = ''; // Senha do MySQL
            $port = 3307;

            try {
                $conexao = new PDO("mysql:host=$host;dbname=$dbname;port=$port", $usuario, $senha);
                $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (PDOException $e) {
                echo '<div class="message-box error">' . "Erro na conexão com o banco de dados: " . $e->getMessage() . '</div>';
            }

            // Verifique se o formulário foi enviado
            if ($_SERVER["REQUEST_METHOD"] === "GET") {
                $pesquisa = isset($_GET["pesquisa"]) ? $_GET["pesquisa"] : "";

                // Consulta SQL para pesquisar usuários
                if (empty($pesquisa)) {
                    $sql = "SELECT * FROM usuarios";
                    $stmt = $conexao->prepare($sql);
                } else {
                    $sql = "SELECT * FROM usuarios WHERE nome LIKE :pesquisa";
                    $stmt = $conexao->prepare($sql);
                    $stmt->bindValue(':pesquisa', '%' . $pesquisa . '%', PDO::PARAM_STR);
                }
                $stmt->execute();
                $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if (count($usuarios) > 0) {
                    // Exiba os resultados da pesquisa
                    echo '<table>';
                    echo '<tr><th>Nome</th><th>Email</th></tr>';
                    foreach ($usuarios as $usuario) {
                        echo '<tr><td>' . $usuario["nome"] . '</td><td>' . $usuario["email"] . '</td></tr>';
                    }
                    echo '</table>';
                } else {
                    echo '<div class="message-box error">Nenhum usuário encontrado.</div>';
                }
            }
            ?>
        </div>
        <script src="main.js"></script>
    </section>
</body>
</html>
