<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="box.css">
</head>
<body>
    <?php
    // Configurações do banco de dados
    $host = "localhost"; // Host do banco de dados
    $dbname = "helybd"; // Nome do banco de dados
    $usuario = "root"; // Nome de usuário do MySQL
    $senha = ""; // Senha do MySQL
    $port= "3307";

    try {
        $conexao = new PDO("mysql:host=$host;dbname=$dbname;port=$port", $usuario, $senha);
        // Configurar o PDO para lançar exceções em caso de erro
        $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo '<div class="message-box error">' . "Erro na conexão com o banco de dados: " . $e->getMessage() . '</div>';
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $username = $_POST["username"];
        $email = $_POST["email"];
        $password = $_POST["password"];

        // Criptografar a senha antes de armazená-la no banco de dados
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO usuarios (nome, email, senha) VALUES (:username, :email, :password)";

        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashedPassword); // Armazenar o hash da senha
        $stmt->execute();

        echo '<div class="message-box success">' . "Username: $username<br>E-mail: $email<br>Olá $username, Bem-vindo ao Hely" . '</div>';
    }
    ?>
</body>
</html>
