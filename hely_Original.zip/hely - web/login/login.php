<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="box.css">
</head>
<body>
    <?php
    // Conexão com o banco de dados
    $host = "localhost"; // Host do banco de dados (geralmente "localhost" para XAMPP)
    $dbname = "helybd"; // Nome do banco de dados
    $usuario = "root"; // Nome de usuário do MySQL
    $senha = ""; // Senha do MySQL (deixe em branco se você não definiu uma senha)
    $port= "3307";

    try {
        $conexao = new PDO("mysql:host=$host;dbname=$dbname;port=$port", $usuario, $senha);
        // Configurar o PDO para lançar exceções em caso de erro
        $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo '<div class="message-box error">' . "Erro na conexão com o banco de dados: " . $e->getMessage() . '</div>';
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];
    
        // Consulta SQL para verificar se o usuário existe no banco de dados
        $consulta = "SELECT * FROM usuarios WHERE nome = :username";
    
        try {
            $stmt = $conexao->prepare($consulta);
            $stmt->bindParam(':username', $username);
            $stmt->execute();
    
            // Verificar se o usuário foi encontrado no banco de dados
            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $hashedPassword = $row['senha'];
    
                // Verificar a senha usando password_verify
                if (password_verify($password, $hashedPassword)) {
                    echo '<div class="message-box success">' . "Olá $username, você está logado com sucesso!" . '</div>';
                } else {
                    echo '<div class="message-box error">' . "Senha incorreta." . '</div>';
                }
            } else {
                echo '<div class="message-box error">' . "Nome de usuário não encontrado." . '</div>';
            }
        } catch (PDOException $e) {
            echo '<div class="message-box error">' . "Erro na consulta ao banco de dados: " . $e->getMessage() . '</div>';
        }
    
    }
    ?>
</body>
</html>
