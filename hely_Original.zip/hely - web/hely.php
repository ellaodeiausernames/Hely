<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title> Hely</title>
     <!--style import-->
    <link href="hely.css" rel="stylesheet"> 
    <!--icons gratuitos import-->
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>
<body>
    
    <section>
          <div class="circle"></div>
    <header>

            <a href="#"> <img src="img/logo.png" alt="" class="logo"> </a>
            <div class="bx bx-menu" id="menu-icon"></div>

            <ul class="navbar">

                <li class="dropdown" >
                <a href="javascript:void(0)" class="dropbtn" id="dropbtn">Menu</a>
                    <div class="dropdown-content" >
                        <a href="login/index.php" >Cadastre-se</a>
                        <a href="login/index.php">Entre</a>
                        <a href="login/listagem.php">Listagem</a>
                    </div></li>

                <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn" id="dropbtn">Todos</a>
                <div class="dropdown-content">
                    <a href="#familia">Familia</a>
                    <a href="#amigos">Amigos</a>
                    <a href="login/listagem.php">Listagem</a>
                </div></li>

                <li id="nav"><a href="#favoritos">Favoritos</a></li>

               <li id="nav" ><a href="#sobre">Sobre</a></li>
        </ul>
    
    </header>


    <!--MENU PRINCIPAL-->

     <div class="content" id="menu">
        

    <div class="textbox">

        <h2>Encontre seu lugar<br><span>Hely</span></h2>
        <p>Quer receber novidade sempre que poder? <br>Entre ou cadastre-se!</p>
         <a href="login/index.php" class="btn">Participe!</a>
       
    </div>
    <div class="imgbox">
        <img src="img/bananacafe.png" class="bananacafe">
    </div>
     </div>
    
    <ul class="thumb">

    <li><img src="img/cafe.png" onclick="imgSlider('img/bananacafe.png');changeCircleColor('#422f26')"></li>
    <li><img src="img/show.png"  onclick="imgSlider('img/capital.png');changeCircleColor('#4e0303')"></li>
    <li><img src="img/idea.png"  onclick="imgSlider('img/observatorio.jpg');changeCircleColor('#030244')"></li>
    
    </ul>

    <ul class="sci">
        <li><a href="#"><img src="img/facebook.png" alt=""></a></li>
        <li><a href="#"><img src="img/instagram.png" alt=""></a></li>
        <li><a href="#"><img src="img/twitter.png" alt=""></a></li>
    </ul>

     </section>
     <script type="text/javascript">
        function imgSlider(anything){
            document.querySelector('.bananacafe').src = anything
        }

        function changeCircleColor(color){
            const circle = document.querySelector('.circle');
            circle.style.background = color;
        }
    </script>
    <script src="main.js"></script>
</body>
</html>